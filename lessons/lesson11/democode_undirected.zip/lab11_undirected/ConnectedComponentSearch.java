package lab11_undirected;


//implement
public class ConnectedComponentSearch extends DepthFirstSearch {
	public ConnectedComponentSearch(Graph graph) {
		super(graph);
	}	
}
