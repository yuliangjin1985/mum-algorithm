package lab11_undirected;

//implement
public class BreadthFirstSearch extends AbstractGraphSearch {

	@Override
	protected boolean someVertexUnvisited() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected void handleInitialVertex() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void singleComponentLoop() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void additionalProcessing() {
		// TODO Auto-generated method stub
		
	}

}
