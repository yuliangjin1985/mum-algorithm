package lecture_10.editdistance;

public class EditDistanceIterative {

	public static void main(String[] args) {

		System.out.println(EditDistanceIterative.editDist("duck", "tug"));
	}

	public static int editDist(String x, String y){
		int n = x.length();
		int m = y.length();
		int[][] D = new int[n+1][m+1]; 
		D[0][0] = 0;
		for(int i = 1; i <= n; i++)
			D[i][0] = i;
		for(int j = 1; j <= m; j++)
			D[0][j] = j;
		for(int i = 1; i <= n; i++) { 
			for(int j = 1; j <= m; j++) {
				if (x.charAt(i-1) == y.charAt(j-1))
					D[i][j] = D[i-1][j-1];
				else
					D[i][j] = Min.min(D[i-1][j], D[i][j-1], D[i-1][j-1]) + 1;
			}
		}
//		for(int i = 0; i <= n; i++) { 
//			for(int j = 0; j <= m; j++) {
//				System.out.print(D[i][j] + " ");
//			}
//			System.out.println("");
//		}
		return D[n][m];
	}



}
