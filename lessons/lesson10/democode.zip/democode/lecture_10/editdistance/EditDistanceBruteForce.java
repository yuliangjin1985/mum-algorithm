package lecture_10.editdistance;

public class EditDistanceBruteForce {
	
	static int numberOfSelfCall = -1;
	
	public static void main(String[] args) {

//		System.out.println(editDist("duck", "tug"));
		System.out.println(editDist("duckduckduck", "tugracktick"));
		System.out.println("Number of Self Call: " + numberOfSelfCall);
	}

	public static int editDist(String x, String y){
		numberOfSelfCall ++;
		int n = isLengthZero(x) ? 0 : x.length();
		int m = isLengthZero(y) ? 0 : y.length();
		
		if (m == 0)
			return n;
		if (n == 0)
			return m;
		if(x.charAt(n-1) == y.charAt(m-1))
			return editDist(x.substring(0, n-1), y.substring(0, m-1));
		else
			return Min.min(editDist(x.substring(0, n-1), y.substring(0, m-1)) + 1, 
					   editDist(x, y.substring(0, m-1)) + 1, 
					   editDist(x.substring(0, n-1), y) + 1);
	}

	private static boolean isLengthZero(String x) {
		return x == null || x.isEmpty();
	}
}
