package lecture_10.subsetsum;

public class Key {
	
	Key(int len, int k) {
		this.len = len;
		this.k = k;
	}
	int len;
	int k;
	public boolean equals(Object ob) {
		if(ob == null) return false;
		if(!(ob instanceof Key)) return false;
		Key key = (Key)ob;
		return k == key.k && len == key.len;
	}
	public int hashCode() {
		return 3 * k + 5 * len;
	}
	public int getLen() {
		return len;
	}
	public int getK() {
		return k;
	}

}
